package dao;

import java.util.HashMap;
import java.util.Random;

import bean.Customer;

public class DaoImple implements DaoInterface {
	HashMap<Long, Customer> customermap = new HashMap<Long,Customer>();
	
	

	@Override
	public long createAccount(long accno,Customer c) {
		// TODO Auto-generated method stub
		 customermap.put(accno,c);
		 System.out.println(customermap);
	
	if(customermap.isEmpty()) {
		System.out.println("ACCOUNT IS NOT CREATED!!!!");
	}
	else {
		System.out.println("ACCOUNT IS SUCCESFULLY CREATED!!!!");
	}
	  
	    
		
	return accno;	
	}



	@Override
	public Customer displayAccount(long accno) {
		// TODO Auto-generated method stub
		Customer cust=null;
		System.out.println("THE DETAILS OF THE CUSTOMER"+customermap);
		
		for(Customer customermap:customermap.values()) {
			if(customermap.getAccno()==accno) {
				System.out.println("The account details are"+customermap);
	
			
				
			}
		
			
		}
		return cust;
			
		}



	@Override
	public float showBalance(long accno, int pin) {
		// TODO Auto-generated method stub
		for (Customer customermap:customermap.values()) {
			if(customermap.getAccno()==accno) {
				if(customermap.getPin()==pin) {
					System.out.println("The balance present in the account"+ "  "+ customermap.accno +"  "+ customermap.balance);
				}
			}
		}
		return 0;
	}



	@Override
	public float deposit(float depositamt, long accno, int pin, int cid) {
		// TODO Auto-generated method stub
		for(Customer customermap:customermap.values()) {
			if(customermap.getAccno()==accno) {
				
				if(customermap.getPin()==pin) {
					
					if(customermap.getCid()==cid) {
						System.out.println("The amount present in your account is"+customermap.balance);
						float amt=customermap.getBalance();
						amt=amt+depositamt;
						System.out.println("The amount present in your account after the deposit is"+ amt);
						
					}
				}
			}
		}
		return 0;
	}



	@Override
	public float withdraw(float withdrawamt, long accno, int pin, int cid) {
		// TODO Auto-generated method stub
		for(Customer customermap:customermap.values()) {
			if(customermap.getAccno()==accno) {
				
				if(customermap.getPin()==pin) {
					
					if(customermap.getCid()==cid) {
						System.out.println("The amount present in your account is"+customermap.balance);
						float amt=customermap.getBalance();
						amt=amt-withdrawamt;
						System.out.println("The amount present in your account after the withdrawl is:"+ amt);
						
					}
				}
			}
		}
		return 0;
	}



	@Override
	public float fundTransfer(long accno, int pin, int cid, long taccno, float transferamt) {
		// TODO Auto-generated method stub
		for(Customer customermap:customermap.values()) {
			if(customermap.cid==cid && customermap.accno==accno && customermap.pin==pin) {
				
				
						float amt=customermap.getBalance();
					
						if(transferamt<amt) {
							amt=amt-transferamt;
							System.out.println("the amount in your acciount after transferring the amount is:"+amt);
							
							}
							
						}
		
					
				
				
			}
	for(Customer customermap2:customermap.values()) {
		if(customermap.containsKey(taccno)) {
			float amt1=customermap2.getBalance();
			amt1=amt1+transferamt;
			customermap2.setBalance(amt1);
			System.out.println("the amount present in your account aftyer the deposited is"+amt1);
		}
	}
		

		
		return 0;
	}
	




	

}
