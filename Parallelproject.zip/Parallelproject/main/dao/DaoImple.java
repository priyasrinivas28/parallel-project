package dao;

import java.util.HashMap;
import java.util.Random;

import bean.Customer;

public class DaoImple implements DaoInterface {
	HashMap<Long, Customer> customermap = new HashMap<Long,Customer>();
	
	

	@Override
	public long createAccount(long accno,Customer c) {
		// TODO Auto-generated method stub
		 customermap.put(accno,c);
		 System.out.println(customermap);
	
	if(customermap.isEmpty()) {
		System.out.println("ACCOUNT IS NOT CREATED!!!!");
	}
	else {
		System.out.println("ACCOUNT IS SUCCESFULLY CREATED!!!!");
	}
	  
	    
		
	return accno;	
	}



	@Override
	public Customer displayAccount(long accno) {
		// TODO Auto-generated method stub
		
		System.out.println("THE DETAILS OF THE CUSTOMER"+customermap);
		
		Customer cust=null;
		return cust;
	}



	@Override
	public float showBalance(Customer c) {
		// TODO Auto-generated method stub
		Customer cust=null;
		for (Customer c : custlist) {
			if(c.getCid()== cid){
				cust=c;
				
			}
	}

	

}
