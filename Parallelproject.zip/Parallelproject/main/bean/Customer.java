package bean;

public class Customer {
private String firstname;
private String middlename;
private String lastname;

private long phoneno;
private String address;
private float balance;
private int age;
public long accno;
private int pin;
public Customer() {
	
}

public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}

public String getFirstname() {
	return firstname;
}
public void setFirstname(String firstname) {
	this.firstname = firstname;
}
public String getMiddlename() {
	return middlename;
}
public void setMiddlename(String middlename) {
	this.middlename = middlename;
}
public String getLastname() {
	return lastname;
}
public void setLastname(String lastname) {
	this.lastname = lastname;
}
public long getPhoneno() {
	return phoneno;
}
public void setPhoneno(long phoneno) {
	this.phoneno = phoneno;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public float getBalance() {
	return balance;
}
public void setBalance(float balance) {
	this.balance = balance;
}public long getAccno() {
	return accno;
}

public void setAccno(long accno) {
	this.accno = accno;
}

public int getPin() {
	return pin;
}

public void setPin(int pin) {
	this.pin = pin;
}
@Override
public String toString() {
	return "Customer [firstname=" + firstname + ", middlename=" + middlename + ", lastname="
			+ lastname + ", phoneno=" + phoneno + ", address=" + address + ", balance=" + balance + ", age=" + age
			+ ", accno=" + accno + ", pin=" + pin + "]";
}


}
