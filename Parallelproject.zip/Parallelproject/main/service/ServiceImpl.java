package service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import bean.Customer;
import dao.DaoImple;
import ui.Client;

public class ServiceImpl implements ServiceInterface{
	DaoImple dao=new DaoImple();
	Client cli=new Client();


	@Override
	public long createAccount(long accno,Customer c) {
		// TODO Auto-generated method stub
		return dao.createAccount(accno,c);
	}

/*public boolean validateData(Customer c) {
	boolean flag=false;
	if(c.getAddress()=="chennai" && c.getAge()>=18 && c.getBalance()>=500 && c.getPhoneno()==10) {
		return true;
	}
	return flag;
	
}*/

@Override
public Customer displayAccount(long accno) {
	// TODO Auto-generated method stub
	return dao.displayAccount(accno);
}

@Override
public float showBalance(long accno, int pin) {
	// TODO Auto-generated method stub
	return dao.showBalance(accno, pin);
}

@Override
public float deposit(float depositamt, long accno, int pin, int cid) {
	// TODO Auto-generated method stub
	return dao.deposit(depositamt, accno, pin, cid);
}

@Override
public float withdraw(float withdrawamt, long accno, int pin, int cid) {
	// TODO Auto-generated method stub
	return dao.withdraw(withdrawamt, accno, pin, cid);
}

@Override
public float fundTransfer(long accno, int pin, int cid, long taccno, float transferamt) {
	// TODO Auto-generated method stub
	return dao.fundTransfer(accno,pin,cid,taccno,transferamt);
}

public boolean validateName(String firstname) {
	boolean flag=false;
	String s=firstname; 
    Pattern pattern = Pattern.compile(new String ("^[a-z0-9_-]{3,15}$"));
    /*# Start of the line
    [a-z0-9_-]	     # Match characters and symbols in the list, a-z, 0-9, underscore, hyphen
               {3,15}  # Length at least 3 characters and maximum length of 15 
  $                    # End of the line*/
    Matcher matcher = pattern.matcher(s);
    if(matcher.matches())
    {
         flag=true;
    }
       //if pattern does not matches
	return flag;
    
	
	
}
public boolean validatePin(int pin) {
	boolean flag=false;
	String expression = "^[0-9]{3-4}*$";
	
	CharSequence inputStr = String.valueOf(pin);
	Pattern pattern = Pattern.compile(expression);
	Matcher matcher = pattern.matcher(inputStr);
	if(matcher.matches()){
	flag=true;
	}
	return flag;
	}
	

public boolean validateAccountNumber(long accno) {
	boolean flag=false;
	String expression = "^[-+]?[0-9]*\\\\.?[0-9]+$";//is numeric
	
	CharSequence inputStr = String.valueOf(accno);
	Pattern pattern = Pattern.compile(expression);
	Matcher matcher = pattern.matcher(inputStr);
	if(matcher.matches()){
	flag=true;
	}
	return flag;
	}
public boolean validatePhonenumber(long phoneno) {
	boolean flag=false;
	String expression = "^\\(?(\\d{3})\\)?[- ]?(\\d{3})[- ]?(\\d{4})$";
	/*^\\(? : May start with an option "(" .
			(\\d{3}): Followed by 3 digits.
			\\)? : May have an optional ")" 
			[- ]? : May have an optional "-" after the first 3 digits or after optional ) character. 
			(\\d{3}) : Followed by 3 digits. 
			 [- ]? : May have another optional "-" after numeric digits.
			 (\\d{4})$ : ends with four digits.*/
	
	CharSequence inputStr = String.valueOf(phoneno);
	Pattern pattern = Pattern.compile(expression);
	Matcher matcher = pattern.matcher(inputStr);
	if(matcher.matches()){
	flag=true;
	}
	return flag;
	
}
public boolean validateAddress(String address) {

	boolean flag=false;
	 
    Pattern pattern = Pattern.compile(new String ("^[#.0-9a-zA-Z\\s,-]+$"));
    /*^[#.0-9a-zA-Z\s,-]+$
    E.g. for Address match case

    #1, North Street, Chennai - 11 
    E.g. for Address not match case

    $1, North Street, Chennai @ 11
*/
    Matcher matcher = pattern.matcher(address);
    if(matcher.matches())
    {
         flag=true;
    }
       //if pattern does not matches
	return flag;
    



}
public boolean validateAge(Customer c) {
	boolean flag = false;
	if(c.getAge()>=18){
		
		flag=true;
		
	}
	
	return flag;
}

public boolean validateCid(int cid) {
	boolean flag=false;
	String expression = ("^[0-9]{3-4}*$");
	
	CharSequence inputStr = String.valueOf(cid);
	Pattern pattern = Pattern.compile(expression);
	Matcher matcher = pattern.matcher(inputStr);
	if(matcher.matches()){
	flag=true;
	}
	return flag;





}


public boolean validateBalance(Customer c) {
	boolean flag= false;
	if(c.getBalance()>500) {
		flag=true;
	}
return flag;	
}
	

}
