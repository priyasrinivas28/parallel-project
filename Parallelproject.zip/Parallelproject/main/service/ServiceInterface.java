package service;

import bean.Customer;

public interface ServiceInterface {
	public long createAccount(long accno,Customer c);
	public Customer displayAccount(long accno);
	public float showBalance(long accno,int pin);
	public float deposit(float depositamt,long accno,int pin,int cid);
	public float withdraw(float withdrawamt,long accno,int pin,int cid);
	public float fundTransfer(long accno,int pin,int cid,long taccno,float transferamt);
	

}
