package ui;

import java.util.Random;
import java.util.Scanner;

import bean.Customer;
import dao.DaoImple;
import service.ServiceImpl;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ServiceImpl serviceobj= new ServiceImpl();
		Random rand = new Random();
		Customer custobj=new Customer();
		while(true){
			
		System.out.println("WELCOME TO custobjobjOMER MANAGEMENT SYSTEM");
		System.out.println("1.CREATE ACCOUNT");
		System.out.println("2.DISPLAY ACCOUNT DETAILS");
		System.out.println("3.SHOW BALANCE");
		System.out.println("4.DEPOSIT");
		System.out.println("5.WITHDRAW");
		System.out.println("6.FUND TRANSFER");
		System.out.println("7.PRINT TRANSACTION");
		System.out.println("8.EXIT");
		
		System.out.println("ENTER YOUR CHOICE");
Scanner sc= new Scanner(System.in);
int ch=sc.nextInt();

switch(ch){
case 1:
	System.out.println("WELCOME TO BANK MANAGEMENT SYSTEM");
	do {
	System.out.println("ENTER THE CUSTOMER ID");
	int cid=sc.nextInt();
	custobj.setCid(cid);
	}while(!serviceobj.validateCid(custobj.cid));
	
	
	do {
	System.out.println("ENTER YOUR FIRSTNAME");
	String firstname= sc.next();
	custobj.setFirstname(firstname);
	}while(!serviceobj.validateName(custobj.firstname));
	
	
	System.out.println("ENTER YOUR MIDDLENAME");
	String middlename= sc.next();
	System.out.println("ENTER YOUR LASTNAME");
	String lastname= sc.next();
	
	do {
	System.out.println("ENTER YOUR age");
	int age=sc.nextInt();
	custobj.setAge(age);
	}while(!serviceobj.validateAge(custobj));
	
	do {
	System.out.println("ENTER YOUR PHONE NUMBER");
	long phoneno =sc.nextLong();
	custobj.setPhoneno(phoneno);
	}while(!serviceobj.validatePhonenumber(custobj.phoneno));
	
	do {
	System.out.println("ENTER YOUR ADDRESS");
	String address =sc.next();
	custobj.setAddress(address);
	}while(!serviceobj.validateAddress(custobj.address));
	
	do {
	System.out.println("ENTER THE BALANCE");
	float balance =sc.nextFloat();
	custobj.setBalance(balance);
	}while(!serviceobj.validateBalance(custobj));
	
	long accno = 1000+rand.nextInt(1000); 
	System.out.println("YOUR ACCOUNT NUMBER FOR THE "+custobj.getFirstname()+custobj.getMiddlename()+custobj.getLastname()+"IS"+accno);
	int pin = 100+rand.nextInt(1000);
	System.out.println("YOUR PIN FOR THE ACCOUNT NUMBER "+accno+ "IS" + pin);
	
	
	
	
custobj.setLastname(lastname);
custobj.setMiddlename(middlename);
custobj.setLastname(lastname);

custobj.setAccno(accno);
custobj.setPin(pin);




serviceobj.createAccount(accno, custobj);





	
	
	

break;

case 2:
	System.out.println("enter the account number");
	long accno1=sc.nextLong();
	
Customer c= serviceobj.displayAccount(custobj.getAccno());

	break;
	


		case 3:
			System.out.println("enter accno to get the record");
	long accno2=sc.nextLong();
	System.out.println("enter the pin for the account ");
	int pin1=sc.nextInt();
	serviceobj.showBalance(accno2, pin1);
	
			
				
			/*	if(c!=null)
					System.out.println(c);
			else{
					try{
						throw new CustomerNotFound();
					} catch(CustomerNotFound e){
						e.printStackTrace();
						
					}
				}*/
			
			
			break;
		case 4:
			System.out.println("enter the customer id");
			int cid1= sc.nextInt();
			System.out.println("enter the account number");
			long accno3=sc.nextLong();
			System.out.println("enter the pin for the account");
			int pin2=sc.nextInt();
			System.out.println("enter the amount to be deposited");
			float depositamt=sc.nextFloat();
			serviceobj.deposit(depositamt, accno3, pin2, cid1);
			break;
		case 5:
			System.out.println("enter the customer id");
			int cid2= sc.nextInt();
			System.out.println("enter the account number");
			long accno4=sc.nextLong();
			System.out.println("enter the pin for the account");
			int pin3=sc.nextInt();
			System.out.println("enter the amount to be withdrawed");
			float withdrawamt=sc.nextFloat();
			serviceobj.withdraw(withdrawamt, accno4, pin3, cid2);
			break;
		case 6:
			
		System.out.println("ENTER YOUR CUSTOMER CID");
				int cid3= sc.nextInt();
				System.out.println("Enter your account number");
				long accno5=sc.nextLong();
				System.out.println("enter your ccount pin");
				int pin4=sc.nextInt();
				System.out.println("enter the accno to be transferred");
				long taccno=sc.nextLong();
				System.out.println("enter the amount to be transferred");
				float transferamt=sc.nextFloat();
				serviceobj.fundTransfer(taccno, pin4, cid3, taccno, transferamt);
				
			break;
		case 7:
			break;
		case 8:
			System.exit(0);
			break;
		 default:
			break;
			

	
	}
}
	}
}