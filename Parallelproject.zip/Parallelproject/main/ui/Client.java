package ui;

import java.util.Random;
import java.util.Scanner;

import bean.Customer;
import dao.DaoImple;
import service.ServiceImpl;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ServiceImpl serviceobj= new ServiceImpl();
		Random rand = new Random();
		Customer custobj=new Customer();
		while(true){
			
		System.out.println("WELCOME TO custobjobjOMER MANAGEMENT SYSTEM");
		System.out.println("1.CREATE ACCOUNT");
		System.out.println("2.DISPLAY ACCOUNT DETAILS");
		System.out.println("3.SHOW BALANCE");
		System.out.println("4.DEPOSIT");
		System.out.println("5.WITHDRAW");
		System.out.println("6.FUND TRANSFER");
		System.out.println("7.PRINT TRANSACTION");
		System.out.println("8.EXIT");
		
		System.out.println("ENTER YOUR CHOICE");
Scanner sc= new Scanner(System.in);
int ch=sc.nextInt();

switch(ch){
case 1:
	System.out.println("WELCOME TO BANK MANAGEMENT SYSTEM");
	System.out.println("ENTER THE CUSTOMER ID");
	
	System.out.println("ENTER YOUR FIRSTNAME");
	String firstname= sc.next();
	System.out.println("ENTER YOUR MIDDLENAME");
	String middlename= sc.next();
	System.out.println("ENTER YOUR LASTNAME");
	String lastname= sc.next();
	System.out.println("ENTER YOUR age");
	int age=sc.nextInt();
	System.out.println("ENTER YOUR PHONE NUMBER");
	long phoneno =sc.nextLong();
	System.out.println("ENTER YOUR ADDRESS");
	String address =sc.next();
	System.out.println("ENTER THE BALANCE");
	float balance =sc.nextFloat();
	
	
	
	long accno = 1000+rand.nextInt(1000); 
	System.out.println("YOUR ACCOUNT NUMBER FOR THE "+custobj.getFirstname()+custobj.getMiddlename()+custobj.getLastname()+"IS"+accno);
	int pin = 100+rand.nextInt(1000);
	System.out.println("YOUR PIN FOR THE ACCOUNT NUMBER "+accno+ "IS" + pin);
	
	custobj.setAddress(address);
	custobj.setAge(age);
	custobj.setFirstname(firstname);
custobj.setLastname(lastname);
custobj.setMiddlename(middlename);
custobj.setLastname(lastname);
custobj.setPhoneno(phoneno);
custobj.setAccno(accno);
custobj.setPin(pin);
custobj.setBalance(balance);
serviceobj.validateData(custobj);
serviceobj.createAccount(accno, custobj);






	
	
	

break;

case 2:
	
serviceobj.displayAccount(custobj.getAccno());

	break;
	


		case 3:
			System.out.println("enter cid to get the record");
			int id= sc.nextInt();
			
				
				if(c!=null)
					System.out.println(c);
			/*	else{
					try{
						throw new CustomerNotFound();
					} catch(CustomerNotFound e){
						e.printStackTrace();
						
					}
				}*/
			
			
			break;
		case 4:
			break;
		case 5:
			break;
		case 6:
			break;
		case 7:
			break;
		case 8:
			System.exit(0);
			break;
		 default:
			break;
			

	
	}
}
	}
}