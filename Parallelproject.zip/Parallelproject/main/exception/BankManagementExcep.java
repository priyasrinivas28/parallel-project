package exception;

public class BankManagementExcep {

}
