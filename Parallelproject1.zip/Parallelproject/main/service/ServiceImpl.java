package service;

import bean.Customer;
import dao.DaoImple;

public class ServiceImpl implements ServiceInterface{
	DaoImple dao=new DaoImple();

	@Override
	public long createAccount(long accno,Customer c) {
		// TODO Auto-generated method stub
		return dao.createAccount(accno,c);
	}

/*public boolean validateData(Customer c) {
	boolean flag=false;
	if(c.getAddress()=="chennai" && c.getAge()>=18 && c.getBalance()>=500 && c.getPhoneno()==10) {
		return true;
	}
	return flag;
	
}*/

@Override
public Customer displayAccount(long accno) {
	// TODO Auto-generated method stub
	return dao.displayAccount(accno);
}

@Override
public float showBalance(long accno, int pin) {
	// TODO Auto-generated method stub
	return dao.showBalance(accno, pin);
}

@Override
public float deposit(float depositamt, long accno, int pin, int cid) {
	// TODO Auto-generated method stub
	return dao.deposit(depositamt, accno, pin, cid);
}

@Override
public float withdraw(float withdrawamt, long accno, int pin, int cid) {
	// TODO Auto-generated method stub
	return dao.withdraw(withdrawamt, accno, pin, cid);
}


	
}
